package il.co.syntax.finalkotlinproject.utils

class Constants {

    companion object {
        const val BASE_URL = "https://www.omdbapi.com/"
    }
}